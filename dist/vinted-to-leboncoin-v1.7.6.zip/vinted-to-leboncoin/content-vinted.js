// content-vinted.js - v1.7.4 (fix)

function sendToBackground(type, payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response) {
        reject(new Error("Pas de réponse du background"));
        return;
      }
      resolve(response);
    });
  });
}

// Insertion sûre : jamais d'appendChild avec une string (SyntaxError sinon).
function safeInsert(targetEl, nodeOrHtml) {
  if (!targetEl) return;
  if (typeof nodeOrHtml === "string") {
    targetEl.insertAdjacentHTML("beforeend", nodeOrHtml);
  } else {
    targetEl.appendChild(nodeOrHtml);
  }
}

function extractId(url) {
  if (url) {
    const match = url.match(/\/items\/(\d+)/);
    if (match) return match[1];
  }
  return crypto.randomUUID ? crypto.randomUUID() : Date.now().toString() + Math.random().toString(36).slice(2);
}

// Certaines pages Vinted (ex. gestion du dressing) n'affichent aucun texte de
// titre dans la carte article -- seulement photo/vues/favoris/prix. L'URL
// contient toujours un slug lisible ("9546070513-debardeur-bleu...") qu'on
// peut reconvertir en titre correct plutôt que de laisser un champ vide ou
// d'attraper un tooltip par erreur.
function titleFromSlug(url) {
  const match = url.match(/\/items\/\d+-([^/?]+)/);
  if (!match) return "";
  try {
    return decodeURIComponent(match[1])
      .replace(/-/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^./, (c) => c.toUpperCase());
  } catch (e) {
    return match[1].replace(/-/g, " ").trim();
  }
}

function extractItemFromArticle(article) {
  const link =
    article.querySelector('a[href*="/items/"]') ||
    (article.tagName === "A" && article.href ? article : null);

  if (!link) return null;

  const rawHref = link.getAttribute("href") || link.href;
  const url = rawHref.startsWith("http") ? rawHref : new URL(rawHref, location.origin).href;
  const id = extractId(url); // jamais undefined -> plus de put rejeté par IndexedDB

  // IMPORTANT : ne jamais utiliser un sélecteur générique [title] ici -- ça
  // attrape le tooltip du premier élément venu (icône, badge "il y a X
  // minutes"...) au lieu du vrai titre du produit.
  const titleEl = article.querySelector('[data-testid$="--description-title"]') || article.querySelector("h3, h2");
  let title = ((titleEl && titleEl.textContent) || "").trim();
  if (!title) {
    title = titleFromSlug(url);
  }
  title = title.slice(0, 200);

  const priceEl = article.querySelector('[data-testid$="--price-text"]') || article.querySelector('[class*="price"]');
  const price = ((priceEl && priceEl.textContent) || "").trim().slice(0, 20);

  return { id, url, title, price, ts: Date.now() };
}

function scrapeArticles() {
  const nodes = document.querySelectorAll(
    'article[data-testid], a[href*="/items/"], div[data-testid*="item-box"]'
  );

  const pairs = [];
  const seen = new Set();

  nodes.forEach((node) => {
    const item = extractItemFromArticle(node);
    if (item && !seen.has(item.id)) {
      seen.add(item.id);
      pairs.push({ item, node });
    }
  });

  return pairs;
}

async function getImportedIdsSet() {
  const res = await sendToBackground("LBC_GET_ALL_IMPORTED");
  return new Set(res.success ? res.data : []);
}

function addImportedBadge(node, id) {
  if (!node || node.querySelector(`.vc-lbc-badge[data-id="${id}"]`)) return;

  // Le badge est positionné en absolu : on s'assure que le conteneur a un
  // contexte de positionnement, sinon le badge se placerait n'importe où.
  if (getComputedStyle(node).position === "static") {
    node.style.position = "relative";
  }

  const badge = document.createElement("div");
  badge.className = "vc-lbc-badge";
  badge.dataset.id = id;
  badge.textContent = "✓ LBC";
  badge.title = "Déjà envoyé vers Leboncoin";
  badge.style.cssText = `
    position:absolute;top:4px;right:4px;z-index:50;
    background:#2e7d32;color:#fff;font-size:10px;font-weight:700;
    padding:2px 6px;border-radius:4px;pointer-events:none;
    font-family:sans-serif;box-shadow:0 1px 3px rgba(0,0,0,.3);
  `;
  node.appendChild(badge);
}

async function applyImportedBadges(pairs) {
  if (pairs.length === 0) return;
  try {
    const importedIds = await getImportedIdsSet();
    pairs.forEach(({ item, node }) => {
      if (importedIds.has(item.id)) addImportedBadge(node, item.id);
    });
  } catch (err) {
    console.error("[vinted2leboncoin] Échec application des badges Leboncoin", err);
  }
}

async function updateVintedIdsIndex(newIds) {
  if (!newIds || newIds.length === 0) return;

  try {
    const existing = await new Promise((resolve) => {
      chrome.storage.local.get(["vintedIds"], (res) => resolve(res.vintedIds || []));
    });

    const idSet = new Set(existing);
    let changed = false;
    newIds.forEach((id) => {
      if (!idSet.has(id)) {
        idSet.add(id);
        changed = true;
      }
    });

    if (!changed) return;

    await sendToBackground("SAFE_SET", {
      vintedIds: Array.from(idSet),
      lastSync: Date.now(),
    });
  } catch (err) {
    console.error("[vinted2leboncoin] Échec mise à jour index vintedIds", err);
  }
}

async function syncScrapedItems() {
  const pairs = scrapeArticles();
  if (pairs.length === 0) return;

  const items = pairs.map((p) => p.item);
  const results = await Promise.allSettled(items.map((item) => sendToBackground("IDB_PUT", item)));

  const successfulIds = items
    .filter((_, idx) => results[idx].status === "fulfilled" && results[idx].value.success)
    .map((item) => item.id);

  const failedCount = items.length - successfulIds.length;
  if (failedCount > 0) {
    results.forEach((r, idx) => {
      if (r.status === "rejected") {
        console.error(`[vinted2leboncoin] IDB_PUT rejeté pour item ${items[idx].id}:`, r.reason);
      } else if (!r.value.success) {
        console.error(`[vinted2leboncoin] IDB_PUT échoué pour item ${items[idx].id}:`, r.value.error);
      }
    });
  }

  await updateVintedIdsIndex(successfulIds);
  await applyImportedBadges(pairs);

  // Log uniquement une fois les résultats connus, jamais avant.
  console.log(`[vinted2leboncoin] Sync: ${successfulIds.length}/${items.length} items sauvegardés en IndexedDB`);
}

async function getAllItems() {
  const response = await sendToBackground("IDB_GET_ALL");
  return response.success ? response.data : [];
}

// ---------------------------------------------------------------------------
// Transfert d'une fiche unique vers Leboncoin (pré-remplissage, pas de publication auto)
// ---------------------------------------------------------------------------

function isSingleItemPage() {
  return /^\/items\/\d+/.test(location.pathname);
}

function parseJsonLdProduct() {
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  for (const script of scripts) {
    try {
      const data = JSON.parse(script.textContent);
      const candidates = Array.isArray(data) ? data : [data];
      for (const c of candidates) {
        if (c && (c["@type"] === "Product" || c["@type"] === "Offer")) return c;
      }
    } catch (e) {
      // JSON-LD malformé, on ignore et on retombe sur le DOM
    }
  }
  return null;
}

function getImgUrl(img) {
  const candidate =
    img.currentSrc ||
    img.getAttribute("data-src") ||
    img.getAttribute("data-original") ||
    img.src ||
    (img.getAttribute("data-srcset") && img.getAttribute("data-srcset").split(",")[0].trim().split(" ")[0]) ||
    (img.srcset && img.srcset.split(",")[0].trim().split(" ")[0]);

  if (!candidate || candidate.startsWith("data:")) return null; // placeholder lazy-load, pas une vraie image
  return candidate;
}

function extractSingleItemData() {
  const ld = parseJsonLdProduct();

  let title = ld && ld.name;
  let description = ld && ld.description;
  let price =
    ld && ld.offers && (ld.offers.price || (Array.isArray(ld.offers) && ld.offers[0] && ld.offers[0].price));

  if (!title) {
    const titleEl = document.querySelector('h1, [data-testid="item-page-summary-plugin"] h1, [itemprop="name"]');
    title = (titleEl && titleEl.textContent || "").trim();
  }

  if (!description) {
    const descEl = document.querySelector(
      '[data-testid="item-description-content"], [itemprop="description"], [class*="description"]'
    );
    description = (descEl && descEl.textContent || "").trim();
  }

  if (!price) {
    const priceEl = document.querySelector('[data-testid$="price"], [itemprop="price"], [class*="price"]');
    price = (priceEl && (priceEl.getAttribute("content") || priceEl.textContent) || "").trim();
  }

  // Sélecteur exact confirmé sur le DOM Vinted (data-testid="item-photo-N--img"),
  // en priorité absolue avant le fallback générique.
  const exactImages = Array.from(document.querySelectorAll('img[data-testid^="item-photo-"]'))
    .map(getImgUrl)
    .filter(Boolean);

  // Le JSON-LD ne contient souvent qu'une seule image "principale" -> on
  // fusionne toujours avec les vignettes du DOM (galerie/carrousel), en
  // gérant le lazy-loading (data-src) qui piège un scrape src-only.
  const domImages = Array.from(
    document.querySelectorAll(
      '[data-testid*="gallery"] img, [data-testid*="photo"] img, [class*="gallery"] img, ' +
        '[class*="carousel"] img, [class*="thumbnail"] img, [role="listitem"] img, ' +
        'button img, li img, img[srcset], img[data-src]'
    )
  )
    .map(getImgUrl)
    .filter(Boolean);

  const ldImages = ld && ld.image ? (Array.isArray(ld.image) ? ld.image : [ld.image]) : [];

  const images = Array.from(new Set([...exactImages, ...domImages, ...ldImages])).slice(0, 20);

  console.log(`[vinted2leboncoin] Extraction images: ${exactImages.length} exact, ${domImages.length} générique, ${images.length} au total après dédup`);

  return {
    sourceUrl: location.href,
    id: extractId(location.href),
    title: String(title || "").trim().slice(0, 200),
    description: String(description || "").trim().slice(0, 4000),
    price: String(price || "").replace(/[^\d,.\s€]/g, "").trim(),
    images,
    ts: Date.now(),
  };
}

function setButtonImportedState(btn, imported) {
  const existingLink = document.getElementById("vc-lbc-reimport-link");
  if (existingLink) existingLink.remove();

  if (imported) {
    btn.textContent = "✓ Importé sur Leboncoin";
    btn.disabled = true;
    btn.style.background = "#2e7d32";
    btn.style.cursor = "default";

    const link = document.createElement("a");
    link.id = "vc-lbc-reimport-link";
    link.href = "#";
    link.textContent = "réimporter";
    link.style.cssText = "margin-left:10px;font-size:12px;color:#666;text-decoration:underline;cursor:pointer;";
    link.addEventListener("click", async (e) => {
      e.preventDefault();
      const id = extractId(location.href);
      await sendToBackground("LBC_UNMARK_IMPORTED", { id });
      setButtonImportedState(btn, false);
    });
    btn.insertAdjacentElement("afterend", link);
  } else {
    btn.textContent = "Envoyer vers Leboncoin";
    btn.disabled = false;
    btn.style.background = "#ff6e14";
    btn.style.cursor = "pointer";
  }
}

function injectLeboncoinTransferButton() {
  if (document.getElementById("vc-lbc-transfer-btn")) return; // déjà injecté

  const anchor =
    document.querySelector('[data-testid="item-page-summary-plugin"]') ||
    document.querySelector("h1")?.closest("div") ||
    document.body;

  if (!anchor) return;

  safeInsert(
    anchor,
    `<button id="vc-lbc-transfer-btn" style="
        margin:10px 0;padding:10px 14px;background:#ff6e14;color:#fff;border:none;
        border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;
      ">Envoyer vers Leboncoin</button>`
  );

  const btn = document.getElementById("vc-lbc-transfer-btn");
  const itemId = extractId(location.href);

  // Vérifie l'état persisté au chargement (fix issue #3 : ne redevient plus
  // "Envoyer vers Leboncoin" après un rechargement/retour sur la page).
  sendToBackground("LBC_CHECK_IMPORTED", { id: itemId })
    .then((res) => {
      if (res.success && res.data) setButtonImportedState(btn, true);
    })
    .catch(() => {});

  btn.addEventListener("click", async () => {
    btn.disabled = true;
    btn.textContent = "Préparation...";

    try {
      const payload = extractSingleItemData();
      if (!payload.title) {
        throw new Error("Impossible d'extraire le titre de l'annonce");
      }

      const res = await sendToBackground("LBC_PREPARE", payload);
      if (!res.success) throw new Error(res.error || "Échec préparation");

      await sendToBackground("LBC_MARK_IMPORTED", { id: payload.id });

      btn.textContent = "Ouverture Leboncoin...";
      window.open("https://www.leboncoin.fr/deposer-une-annonce", "_blank");

      setTimeout(() => setButtonImportedState(btn, true), 1200);
    } catch (err) {
      console.error("[vinted2leboncoin] Échec transfert vers Leboncoin", err);
      btn.textContent = "Erreur, réessayer";
      btn.disabled = false;
    }
  });
}

function init() {
  syncScrapedItems();

  if (isSingleItemPage()) {
    injectLeboncoinTransferButton();
  }

  const observer = new MutationObserver(() => {
    clearTimeout(init._debounce);
    init._debounce = setTimeout(() => {
      syncScrapedItems();
      if (isSingleItemPage()) injectLeboncoinTransferButton();
    }, 800);
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}